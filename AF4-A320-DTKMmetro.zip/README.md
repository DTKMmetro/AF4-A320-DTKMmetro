# DTKMmetro · 东航 A320 自定义涂装

用 LiveryStudio 自己画的 Airbus A320 涂装,已转成游戏可用的 `.ttx` 格式并打包好。

![封面](预览.png)

## 一键安装

1. 把压缩包**完整解压**到任意位置
2. 双击 **`一键安装.bat`**
3. 看到「安装完成:共 11 个文件」即可
4. **完全退出** Aerofly FS 4,重新启动
5. 选 A320 → 涂装列表 → **DTKMmetro**

安装位置(脚本自动定位,兼容 OneDrive 重定向):

```
<文档>\Aerofly FS 4\aircraft\a320\dtkmmetro\
```

## 手动安装

把 `dtkmmetro` 整个文件夹复制到:

```
C:\Users\<用户名>\Documents\Aerofly FS 4\aircraft\a320\
```

> 是 `aircraft\a320\`,不是 `addons\aircraft\`。

## 卸载

删掉 `...\Aerofly FS 4\aircraft\a320\dtkmmetro` 整个文件夹即可,游戏自带涂装不受影响。

## 包含的贴图

| 文件 | 格式 | 内容 |
|---|---|---|
| `ext00_misc_color.ttx` | DXT1 4096 | 杂项小件 |
| `ext01/02/03_fuselage_color.ttx` | DXT1 4096 | 机身前 / 中 / 后段 |
| `ext04_stab_color.ttx` | DXT1 4096 | 尾翼 / 吊舱 |
| `ext05_decals_color.ttx` | DXT5 2048 | 舷窗 / 贴花层 |
| `ext06_wings_color.ttx` | DXT1 4096 | 机翼 |
| `int05_selcal_color.ttx` | — | 驾驶舱 SELCAL 面板 |
| `option.tmc` | — | 涂装配置(名称 DTKMmetro) |
| `preview*.ttx` | — | 列表封面 |

贴图来自编辑器项目 `CES-A320`,转码后与源 PNG 的平均像素差约 2.0(纯 DXT 量化,无画质事故)。

## 说明

- 基于游戏自带的 A320 与东航涂装(CFM56 + 翼尖小翼)
- 只写用户文档目录,不修改游戏安装文件
- 若列表里没出现:确认路径层级 `aircraft\a320\dtkmmetro\option.tmc`,再重启游戏
