﻿param([string]$TargetRoot)

$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$src = Join-Path $here 'dtkmmetro'
$folderName = 'dtkmmetro'

Write-Host ''
Write-Host '  东航 A320 · DTKMmetro 涂装  一键安装' -ForegroundColor Cyan
Write-Host '  --------------------------------------' -ForegroundColor DarkGray

if (-not (Test-Path -LiteralPath $src)) {
    Write-Host '  [错误] 找不到 dtkmmetro 文件夹。' -ForegroundColor Red
    Write-Host '  请先把压缩包完整解压,再双击本安装程序。' -ForegroundColor Red
    exit 1
}

$docs = $null
try {
    $reg = Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders' -ErrorAction Stop
    if ($reg.Personal) { $docs = [Environment]::ExpandEnvironmentVariables($reg.Personal) }
} catch { }
if (-not $docs -or -not (Test-Path -LiteralPath $docs)) {
    $docs = [Environment]::GetFolderPath('MyDocuments')
}

if ($TargetRoot) {
    $target = $TargetRoot
    Write-Host ('  [测试模式] 目标: ' + $target) -ForegroundColor Magenta
} else {
    Write-Host ('  文档目录: ' + $docs) -ForegroundColor Gray
    $target = Join-Path $docs 'Aerofly FS 4\aircraft\a320'
}

$running = Get-Process -Name 'aerofly*' -ErrorAction SilentlyContinue
if ($running) {
    Write-Host '  [提示] 检测到 Aerofly 正在运行。' -ForegroundColor Yellow
    Write-Host '         安装后请完全退出游戏再重新启动,否则贴图不会刷新。' -ForegroundColor Yellow
}

if (-not (Test-Path -LiteralPath $target)) {
    New-Item -ItemType Directory -Force -Path $target | Out-Null
    Write-Host ('  已创建目录: ' + $target) -ForegroundColor Gray
}

$dest = Join-Path $target $folderName
if (Test-Path -LiteralPath $dest) {
    Write-Host '  [覆盖] 已存在同名涂装,将更新为最新版本。' -ForegroundColor Yellow
}
New-Item -ItemType Directory -Force -Path $dest | Out-Null
Copy-Item -Path (Join-Path $src '*') -Destination $dest -Force

$n = (Get-ChildItem -LiteralPath $dest -File | Measure-Object).Count
if ($n -lt 11) {
    Write-Host ('  [错误] 复制不完整,只找到 ' + $n + ' 个文件。') -ForegroundColor Red
    exit 1
}

Write-Host ''
Write-Host ('  安装完成:共 ' + $n + ' 个文件') -ForegroundColor Green
Write-Host ('  ' + $dest) -ForegroundColor Gray
Write-Host ''
Write-Host '  下一步:' -ForegroundColor White
Write-Host '   1. 完全退出 Aerofly FS 4' -ForegroundColor White
Write-Host '   2. 重新启动,选择 A320' -ForegroundColor White
Write-Host '   3. 涂装列表里选  DTKMmetro' -ForegroundColor White
Write-Host ''
